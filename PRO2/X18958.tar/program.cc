#include "PilaIOParInt.hh"

using namespace std;

int main() {
    stack<ParInt> p;
    llegirPilaParInt(p);
    escriurePilaParInt(p);
}
