#include "PilaIOParInt.hh"

void llegirPilaParInt(stack<ParInt>& p) {
    int a, b;
    cin >> a >> b;
    while (a != 0 or b != 0) {
        ParInt par(a,b);
        p.push(par);
        cin >> a >> b;
    }
}

void escriurePilaParInt(stack<ParInt> p) {
    int n, m;
    bool trobat = false;
    cin >> n;
    while (not p.empty()) {
        ParInt par = p.top();
        par.escriure();
        if (par.primer() == n and not trobat) {
            m = par.segon();
            trobat = true;
        }
        p.pop();
    }
    if ( trobat) cout << m << endl;
    else cout << "No trobat" << endl;
  
}
