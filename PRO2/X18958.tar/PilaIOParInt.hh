#include <iostream>
#include <stack>
#include "ParInt.hh"

using namespace std;
  
void llegirPilaParInt(stack<ParInt>& p);

void escriurePilaParInt(stack<ParInt> p);
    
