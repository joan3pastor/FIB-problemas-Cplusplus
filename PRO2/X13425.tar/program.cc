#include "CuaIOParInt.hh"

using namespace std;

int main() {
    queue<ParInt> q,q1,q2;
    int time1 = 0;
    int time2 = 0;
    llegirCuaParInt(q);
    while(not q.empty()) {
        if (time1 <= time2) {
            q1.push(q.front());
            time1 += q.front().segon();
        }
        else {
            q2.push(q.front());
            time2 += q.front().segon();
        }
        q.pop();
    }
    escriureCuaParInt(q1);
    cout << endl;
    escriureCuaParInt(q2);
}