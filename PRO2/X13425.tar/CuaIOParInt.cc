#include "CuaIOParInt.hh"

void llegirCuaParInt(queue<ParInt>& c) {
    bool b = true;
    while (b) {
        ParInt par;
        par.llegir();
        if (par.primer() == 0 and par.segon() == 0) b = false;
        else c.push(par); 
    }
}

void escriureCuaParInt(queue<ParInt> c) {
    while (not c.empty()) {
        c.front().escriure();
        c.pop();
    }
}