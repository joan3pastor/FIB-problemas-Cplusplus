#include "CuaIOEstudiant.hh"

using namespace std;

int main() {
    queue<Estudiant> q;
    LlegirCuaEstudiant(q);
    EscriureCuaEstudiant(q);
    int dni;
    cin >> dni;
    bool b = true;
    while (not q.empty() and b) {
        if(dni == q.front().consultar_DNI()) {
            b = false;
            if (q.front().te_nota()) cout << "La nota es " << q.front().consultar_nota() << endl;
            else cout << "No te nota" << endl;
        }
        q.pop();
    }
    if (b) cout << "No trobat" << endl;
}